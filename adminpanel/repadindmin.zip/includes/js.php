<script type="text/javascript" src="js/general.js"></script>
<!-- menu and tabs -->
<!--<script src="js/jquery-1.11.1.min.js"></script> -->
<script src="js/jquery-1.7.1.min.js" type="text/javascript"></script> 
<script src="js/jquery.easytabs.min.js" type="text/javascript"></script>
<!-- menu and tabs -->
<script src="js/ajax.js" type="text/javascript"></script>