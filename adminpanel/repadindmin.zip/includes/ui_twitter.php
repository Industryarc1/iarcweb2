<div class="twit mob_no">
		<img src="images/twitter.jpg">
	</div>