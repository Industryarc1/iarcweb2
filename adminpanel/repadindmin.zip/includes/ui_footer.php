<div class="footer" style="background-color:#EAEFFD;border-top:1px solid #1565B5">
	<div class="wrapper_inner">
        <div class="m_Footer">
        	Copyrights <?=date('Y')?> FURION ANALYTICS RESEARCH & CONSULTING LLP All Rights Reserved.	</div>
    </div>
</div>