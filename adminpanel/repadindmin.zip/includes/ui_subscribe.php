<div class="subscribe mob_no">
                    <h1 class="hd1">Subscribe to newsletter</h1>
                    <input type="text" value="" name="" placeholder="Email" class="text1">
                    <input type="submit" value="Subscribe" name="" class="subscribe1">
                </div>